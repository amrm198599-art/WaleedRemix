package com.waleed.remix

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val viewModel: RemixViewModel by viewModels()
    private lateinit var interstitial: InterstitialManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        initAds(applicationContext)
        interstitial = InterstitialManager(applicationContext)
        interstitial.load()
        setContent {
            RemixTheme {
                RemixApp(
                    vm = viewModel,
                    onShowInterstitial = { interstitial.show(this) },
                )
            }
        }
    }
}
