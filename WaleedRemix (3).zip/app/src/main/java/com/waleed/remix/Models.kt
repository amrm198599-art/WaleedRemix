package com.waleed.remix

import android.net.Uri
import androidx.annotation.StringRes
import kotlin.math.roundToInt

data class MediaEntry(val uri: Uri, val isVideo: Boolean, val durationMs: Long)

/** خلية داخل الشاشة النهائية، كنسب من 0 إلى 1 (من أعلى اليسار). */
data class Cell(val x: Float, val y: Float, val w: Float, val h: Float)

enum class RemixLayout(
    @StringRes val labelRes: Int,
    val canvasW: Int,
    val canvasH: Int,
    val cells: List<Cell>,
) {
    V2(R.string.layout_v2, 1080, 1920, listOf(Cell(0f, 0f, 1f, .5f), Cell(0f, .5f, 1f, .5f))),
    H2(R.string.layout_h2, 1920, 1080, listOf(Cell(0f, 0f, .5f, 1f), Cell(.5f, 0f, .5f, 1f))),
    V3(
        R.string.layout_v3, 1080, 1920,
        listOf(Cell(0f, 0f, 1f, 1f / 3), Cell(0f, 1f / 3, 1f, 1f / 3), Cell(0f, 2f / 3, 1f, 1f / 3)),
    ),
    H3(
        R.string.layout_h3, 1920, 1080,
        listOf(Cell(0f, 0f, 1f / 3, 1f), Cell(1f / 3, 0f, 1f / 3, 1f), Cell(2f / 3, 0f, 1f / 3, 1f)),
    ),
    G4(
        R.string.layout_g4, 1080, 1920,
        listOf(Cell(0f, 0f, .5f, .5f), Cell(.5f, 0f, .5f, .5f), Cell(0f, .5f, .5f, .5f), Cell(.5f, .5f, .5f, .5f)),
    );

    val count: Int get() = cells.size

    fun outW(scale: Float): Int = even(canvasW * scale)
    fun outH(scale: Float): Int = even(canvasH * scale)
    fun cellWidthPx(i: Int, scale: Float): Int = even(cells[i].w * outW(scale))
    fun cellHeightPx(i: Int, scale: Float): Int = even(cells[i].h * outH(scale))

    companion object {
        fun forCount(n: Int): List<RemixLayout> = when (n) {
            2 -> listOf(V2, H2)
            3 -> listOf(V3, H3)
            4 -> listOf(G4)
            else -> emptyList()
        }

        private fun even(v: Float): Int = (v.roundToInt() / 2) * 2
    }
}

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progress: Float) : ExportState
    data class Done(val uri: Uri) : ExportState
    data class Error(val message: String) : ExportState
}
