package com.waleed.remix

import android.app.Application
import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.Size
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.VideoCompositorSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class Screen { HOME, PREVIEW }

class RemixViewModel(app: Application) : AndroidViewModel(app) {

    val items = mutableStateListOf<MediaEntry>()
    var layout by mutableStateOf<RemixLayout?>(null)
        private set
    var useSecondaryAudio by mutableStateOf(false)
        private set
    var screen by mutableStateOf(Screen.HOME)
    var exportState by mutableStateOf<ExportState>(ExportState.Idle)
        private set
    var adShownForCurrentExport = false

    private var transformer: Transformer? = null
    private var exportJob: Job? = null

    val availableLayouts: List<RemixLayout> get() = RemixLayout.forCount(items.size)

    /** الفهرس الذي يُسمع صوته في الدمج. */
    val audioIndex: Int
        get() {
            val wanted = if (useSecondaryAudio) 1 else 0
            val w = items.getOrNull(wanted)
            if (w != null && w.isVideo) return wanted
            return items.indexOfFirst { it.isVideo }
        }

    fun addUris(uris: List<Uri>) {
        viewModelScope.launch {
            val room = 4 - items.size
            val entries = withContext(Dispatchers.IO) { uris.take(room).map { readEntry(it) } }
            items.addAll(entries)
            refreshLayout()
        }
    }

    fun replaceUris(uris: List<Uri>) {
        viewModelScope.launch {
            val entries = withContext(Dispatchers.IO) { uris.take(4).map { readEntry(it) } }
            items.clear()
            items.addAll(entries)
            refreshLayout()
        }
    }

    fun removeAt(index: Int) {
        if (index in items.indices) items.removeAt(index)
        refreshLayout()
    }

    fun reverse() {
        val reversed = items.reversed()
        items.clear()
        items.addAll(reversed)
    }

    fun selectLayout(l: RemixLayout) {
        layout = l
    }

    fun selectSecondaryAudio(secondary: Boolean) {
        useSecondaryAudio = secondary
    }

    fun resetExport() {
        exportState = ExportState.Idle
        adShownForCurrentExport = false
    }

    private fun refreshLayout() {
        val options = availableLayouts
        layout = if (options.isEmpty()) null else if (layout in options) layout else options.first()
        if (items.size < 2) useSecondaryAudio = false
        exportState = ExportState.Idle
    }

    private fun readEntry(uri: Uri): MediaEntry {
        val ctx = getApplication<Application>()
        val type = ctx.contentResolver.getType(uri) ?: ""
        val isVideo = type.startsWith("video")
        var duration = 0L
        if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } catch (_: Exception) {
            } finally {
                try { r.release() } catch (_: Exception) {}
            }
        }
        return MediaEntry(uri, isVideo, duration)
    }

    // ───────────────────────── التصدير ─────────────────────────

    fun export() {
        val l = layout ?: return
        if (items.size < 2 || items.size != l.count) return
        if (exportState is ExportState.Running) return
        val snapshot = items.toList()
        val audioIdx = audioIndex
        adShownForCurrentExport = false
        exportState = ExportState.Running(0f)
        exportJob = viewModelScope.launch {
            val ctx = getApplication<Application>()
            val outFile = File(ctx.cacheDir, "remix_${System.currentTimeMillis()}.mp4")
            // جودة أقل = أسرع وأثبت. لو فشل الدمج بجودة يعيد المحاولة تلقائيًا بجودة أقل.
            val scales = if (snapshot.size >= 3) listOf(2f / 3f, 0.5f) else listOf(1f, 2f / 3f, 0.5f)
            var lastError: Exception? = null
            try {
                for (scale in scales) {
                    try {
                        outFile.delete()
                        exportState = ExportState.Running(0f)
                        val composition = buildComposition(snapshot, l, audioIdx, scale)
                        runTransformer(composition, outFile)
                        val uri = withContext(Dispatchers.IO) { saveToGallery(outFile) }
                        exportState = ExportState.Done(uri)
                        lastError = null
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        lastError = e
                    }
                }
                lastError?.let { exportState = ExportState.Error(it.message ?: it.javaClass.simpleName) }
            } finally {
                outFile.delete()
                transformer = null
            }
        }
    }

    private fun buildComposition(entries: List<MediaEntry>, l: RemixLayout, audioIdx: Int, scale: Float): Composition {
        val maxVideoMs = entries.filter { it.isVideo }.maxOfOrNull { it.durationMs }?.takeIf { it > 0 } ?: 5000L
        val totalUs = maxVideoMs * 1000

        val sequences = entries.mapIndexed { i, e ->
            val effects = Effects(
                emptyList(),
                listOf(
                    Presentation.createForWidthAndHeight(
                        l.cellWidthPx(i, scale),
                        l.cellHeightPx(i, scale),
                        Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
                    ),
                ),
            )
            val item = EditedMediaItem.Builder(MediaItem.fromUri(e.uri)).setEffects(effects)
            if (e.isVideo) {
                item.setRemoveAudio(i != audioIdx)
            } else {
                item.setDurationUs(totalUs).setFrameRate(30)
            }
            val seq = EditedMediaItemSequence.Builder(item.build())
            // الفيديو الأقصر يتكرر حتى ينتهي الأطول
            if (e.isVideo && e.durationMs in 1 until (maxVideoMs - 50)) seq.setIsLooping(true)
            seq.build()
        }

        val settings = object : VideoCompositorSettings {
            override fun getOutputSize(inputSizes: List<Size>): Size = Size(l.outW(scale), l.outH(scale))

            override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
                val c = l.cells[inputId.coerceIn(0, l.cells.lastIndex)]
                val ax = (c.x + c.w / 2f) * 2f - 1f
                val ay = 1f - (c.y + c.h / 2f) * 2f
                return OverlaySettings.Builder()
                    .setBackgroundFrameAnchor(ax, ay)
                    .setOverlayFrameAnchor(0f, 0f)
                    .build()
            }
        }

        return Composition.Builder(sequences)
            .setVideoCompositorSettings(settings)
            .build()
    }

    private suspend fun runTransformer(composition: Composition, outFile: File) {
        val ctx = getApplication<Application>()
        val holder = ProgressHolder()
        coroutineScopeProgress { onProgress ->
            suspendCancellableCoroutine<Unit> { cont ->
                val t = Transformer.Builder(ctx)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            if (cont.isActive) cont.resumeWithException(exportException)
                        }
                    })
                    .build()
                transformer = t
                t.start(composition, outFile.absolutePath)
                onProgress {
                    val state = t.getProgress(holder)
                    if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                        exportState = ExportState.Running(holder.progress / 100f)
                    }
                }
                cont.invokeOnCancellation { t.cancel() }
            }
        }
    }

    /** يشغّل مؤقّت تحديث التقدّم على الخيط الرئيسي طوال تنفيذ [block]. */
    private suspend fun coroutineScopeProgress(
        block: suspend (registerPoll: (() -> Unit) -> Unit) -> Unit,
    ) {
        var poll: (() -> Unit)? = null
        val poller = viewModelScope.launch {
            while (isActive) {
                delay(300)
                poll?.invoke()
            }
        }
        try {
            block { poll = it }
        } finally {
            poller.cancel()
        }
    }

    private fun saveToGallery(file: File): Uri {
        val ctx = getApplication<Application>()
        val name = "WaleedRemix_${System.currentTimeMillis()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/WaleedRemix")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            } else {
                @Suppress("DEPRECATION")
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "WaleedRemix",
                )
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.Video.Media.DATA, File(dir, name).absolutePath)
            }
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Could not create gallery entry")
        resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        }
        return uri
    }

    override fun onCleared() {
        exportJob?.cancel()
        transformer?.cancel()
        super.onCleared()
    }
}
