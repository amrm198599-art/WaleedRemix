# Privacy Policy — waleed remix / سياسة الخصوصية — وليد ريمكس

## English
**waleed remix** merges videos and photos locally on your device.

- Your videos and photos are **never uploaded** to any server. All processing happens on your phone.
- The app only accesses the files you pick yourself, and saves the merged video to your gallery (Movies/WaleedRemix).
- The app shows ads provided by **Google AdMob**. AdMob may use the advertising ID and device information to serve ads, according to Google's Privacy Policy: https://policies.google.com/privacy
- We do not sell or share your personal data.
- You can reset or delete your advertising ID from your phone settings.

Contact / support: **waleedmmh789@gmail.com**

## العربية
تطبيق **وليد ريمكس** يدمج الفيديوهات والصور على جهازك فقط.

- لا يتم **رفع** فيديوهاتك أو صورك إلى أي خادم، وكل المعالجة تتم على هاتفك.
- يصل التطبيق فقط إلى الملفات التي تختارها بنفسك، ويحفظ الفيديو الناتج في معرض الهاتف (Movies/WaleedRemix).
- يعرض التطبيق إعلانات من **Google AdMob**، وقد تستخدم AdMob معرّف الإعلانات ومعلومات الجهاز لعرض الإعلانات وفق سياسة خصوصية Google: https://policies.google.com/privacy
- لا نبيع بياناتك الشخصية ولا نشاركها.
- يمكنك إعادة ضبط معرّف الإعلانات أو حذفه من إعدادات هاتفك.

للتواصل والدعم: **waleedmmh789@gmail.com**
