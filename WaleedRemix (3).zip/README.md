# waleed remix — وليد ريمكس

تطبيق أندرويد (Kotlin + Jetpack Compose + Media3 Transformer) لدمج 2–4 فيديوهات أو صور في فيديو واحد، مع حفظ الناتج في معرض الهاتف.

- minSdk 26 · targetSdk 35 · الحزمة: `com.waleed.remix`
- لغات: العربية والإنجليزية (حسب لغة الهاتف + زر تبديل داخل التطبيق)
- إعلانات AdMob: بانر + بيني (debug = إعلانات اختبار، release = المعرفات الحقيقية)

## الإعداد على GitHub
1. ارفع كل محتويات هذا المجلد إلى ريبو جديد (أو ارفع ملف ZIP في جذر الريبو مع مجلد `.github/workflows`).
2. من الريبو: Settings ← Secrets and variables ← Actions ← New repository secret، وأضف 4 أسرار:
   - `KEYSTORE_BASE64`  (ملف الـ keystore محوّل base64)
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. لتحويل الـ keystore إلى base64:
   - Linux/Mac: `base64 -w 0 release.jks`
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.jks"))`
4. لو ما عندك keystore:
   `keytool -genkeypair -v -keystore release.jks -alias mykey -keyalg RSA -keysize 2048 -validity 10000`
   (استخدم نفس alias الموجود في سر `KEY_ALIAS`).
5. من تبويب Actions شغّل `Build waleed remix (APK + AAB)` أو اعمل push.
6. بعد انتهاء البناء: خد ملفي APK وAAB من Artifacts أو من Releases.

رقم الإصدار يتغير تلقائيًا: `versionCode = رقم الـ run` و`versionName = 1.0.<رقم الـ run>`.

## سياسة الخصوصية
الملف `PRIVACY_POLICY.md`، ونسخة HTML جاهزة في `docs/index.html` (فعّل GitHub Pages من مجلد `/docs` للحصول على رابط تضعه في Google Play).
