package com.waleed.remix

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.os.LocaleListCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RemixApp(vm: RemixViewModel, onShowInterstitial: () -> Unit) {
    val context = LocalContext.current
    var showPrivacy by remember { mutableStateOf(false) }
    var pendingExport by remember { mutableStateOf(false) }

    // اختيار الوسائط: الأساسي (يستبدل) والإضافي (يضيف)
    val pickMulti = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(4),
    ) { uris -> if (uris.isNotEmpty()) vm.replaceUris(uris) }
    val pickMore = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(4),
    ) { uris -> if (uris.isNotEmpty()) vm.addUris(uris) }
    val pickOne = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia(),
    ) { uri -> if (uri != null) vm.addUris(listOf(uri)) }
    val both = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)

    val storagePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted && pendingExport) vm.export(); pendingExport = false }

    fun startExport() {
        val needsPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pendingExport = true
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            vm.export()
        }
    }

    // الإعلان البيني بعد نجاح الحفظ
    val state = vm.exportState
    LaunchedEffect(state) {
        if (state is ExportState.Done && !vm.adShownForCurrentExport) {
            vm.adShownForCurrentExport = true
            onShowInterstitial()
        }
    }

    BackHandler(enabled = vm.screen == Screen.PREVIEW) { vm.screen = Screen.HOME }

    val isArabic = LocalConfiguration.current.locales[0].language == "ar"

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                modifier = Modifier.statusBarsPadding(),
                title = { Text(stringResource(R.string.app_name)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                ),
                actions = {
                    TextButton(onClick = {
                        AppCompatDelegate.setApplicationLocales(
                            LocaleListCompat.forLanguageTags(if (isArabic) "en" else "ar"),
                        )
                    }) {
                        Icon(Icons.Default.Language, contentDescription = stringResource(R.string.language))
                        Spacer(Modifier.size(4.dp))
                        Text(if (isArabic) "EN" else "ع")
                    }
                    IconButton(onClick = { showPrivacy = true }) {
                        Icon(Icons.Default.PrivacyTip, contentDescription = stringResource(R.string.privacy))
                    }
                },
            )
        },
        bottomBar = {
            Box(Modifier.navigationBarsPadding()) { BannerAd() }
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (vm.screen) {
                Screen.HOME -> HomeScreen(
                    vm = vm,
                    onPickMain = { pickMulti.launch(both) },
                    onPickMore = {
                        val room = 4 - vm.items.size
                        if (room >= 2) pickMore.launch(both) else if (room == 1) pickOne.launch(both)
                    },
                    onExport = ::startExport,
                )
                Screen.PREVIEW -> PreviewScreen(vm = vm, onExport = ::startExport)
            }
        }
    }

    if (showPrivacy) PrivacyDialog(context) { showPrivacy = false }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeScreen(
    vm: RemixViewModel,
    onPickMain: () -> Unit,
    onPickMore: () -> Unit,
    onExport: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.intro), style = MaterialTheme.typography.bodyMedium)

        Button(onClick = onPickMain, modifier = Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.VideoLibrary, null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.upload_main))
        }
        OutlinedButton(
            onClick = onPickMore,
            enabled = vm.items.isNotEmpty() && vm.items.size < 4,
            modifier = Modifier.fillMaxWidth().height(52.dp),
        ) {
            Icon(Icons.Default.AddPhotoAlternate, null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.add_more))
        }

        if (vm.items.isEmpty()) {
            Text(stringResource(R.string.empty_state), color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        } else {
            Text(stringResource(R.string.selected_items, vm.items.size), style = MaterialTheme.typography.titleSmall)
            var photoCount = 0
            var videoCount = 0
            vm.items.forEachIndexed { i, item ->
                val label = if (item.isVideo) {
                    videoCount++
                    stringResource(R.string.video_n, videoCount, formatDuration(item.durationMs))
                } else {
                    photoCount++
                    stringResource(R.string.photo_n, photoCount)
                }
                val tag = when (i) {
                    0 -> stringResource(R.string.tag_main)
                    1 -> stringResource(R.string.tag_secondary)
                    else -> ""
                }
                ItemRow(item, label, tag, onRemove = { vm.removeAt(i) })
            }
        }

        if (vm.items.size >= 2) {
            Text(stringResource(R.string.layout_title), style = MaterialTheme.typography.titleSmall)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.availableLayouts.forEach { l ->
                    FilterChip(
                        selected = vm.layout == l,
                        onClick = { vm.selectLayout(l) },
                        label = { Text(stringResource(l.labelRes)) },
                    )
                }
            }

            Text(stringResource(R.string.audio_title), style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = !vm.useSecondaryAudio,
                    onClick = { vm.selectSecondaryAudio(false) },
                    label = { Text(stringResource(R.string.audio_main)) },
                )
                FilterChip(
                    selected = vm.useSecondaryAudio,
                    onClick = { vm.selectSecondaryAudio(true) },
                    label = { Text(stringResource(R.string.audio_secondary)) },
                )
            }

            OutlinedButton(onClick = { vm.reverse() }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.SwapVert, null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.reverse))
            }
            OutlinedButton(onClick = { vm.screen = Screen.PREVIEW }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.preview))
            }
            ExportSection(vm, onExport)
        } else if (vm.items.size == 1) {
            Text(stringResource(R.string.need_two), color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ItemRow(item: MediaEntry, label: String, tag: String, onRemove: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center,
            ) {
                if (item.isVideo) {
                    Icon(Icons.Default.Movie, null, tint = MaterialTheme.colorScheme.primary)
                } else {
                    AsyncImage(
                        model = item.uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(label)
                if (tag.isNotEmpty()) {
                    Text(tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Default.Close, contentDescription = stringResource(R.string.remove))
            }
        }
    }
}

@Composable
private fun ExportSection(vm: RemixViewModel, onExport: () -> Unit) {
    val context = LocalContext.current
    when (val s = vm.exportState) {
        is ExportState.Running -> {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.exporting, (s.progress * 100).toInt()))
                LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
                Text(stringResource(R.string.keep_open), style = MaterialTheme.typography.labelSmall)
            }
        }
        else -> {
            Button(
                onClick = onExport,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.secondary,
                    contentColor = androidx.compose.ui.graphics.Color.White,
                ),
            ) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.export_btn))
            }
            if (s is ExportState.Done) {
                Text(stringResource(R.string.saved), color = MaterialTheme.colorScheme.primary)
                TextButton(onClick = {
                    val intent = Intent(Intent.ACTION_VIEW).setDataAndType(s.uri, "video/mp4")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    try { context.startActivity(intent) } catch (_: Exception) {}
                }) { Text(stringResource(R.string.open_video)) }
            }
            if (s is ExportState.Error) {
                Text(stringResource(R.string.error_fmt, s.message), color = androidx.compose.ui.graphics.Color(0xFFFF6B6B))
            }
        }
    }
}

@Composable
private fun PreviewScreen(vm: RemixViewModel, onExport: () -> Unit) {
    val layout = vm.layout
    Column(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (layout != null && vm.items.size == layout.count) {
            val audioIdx = vm.audioIndex
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                BoxWithConstraints(
                    Modifier
                        .aspectRatio(layout.canvasW.toFloat() / layout.canvasH)
                        .clip(RoundedCornerShape(12.dp))
                        .background(androidx.compose.ui.graphics.Color.Black),
                ) {
                    val w = maxWidth
                    val h = maxHeight
                    layout.cells.forEachIndexed { i, c ->
                        val item = vm.items[i]
                        Box(Modifier.offset(w * c.x, h * c.y).size(w * c.w, h * c.h)) {
                            if (item.isVideo) {
                                VideoCell(item.uri, muted = i != audioIdx, modifier = Modifier.fillMaxSize())
                            } else {
                                AsyncImage(
                                    model = item.uri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    }
                }
            }
        }
        ExportSection(vm, onExport)
        OutlinedButton(onClick = { vm.screen = Screen.HOME }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
            Spacer(Modifier.size(8.dp))
            Text(stringResource(R.string.back))
        }
    }
}

@Composable
private fun VideoCell(uri: Uri, muted: Boolean, modifier: Modifier) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            repeatMode = Player.REPEAT_MODE_ALL
            prepare()
            playWhenReady = true
        }
    }
    LaunchedEffect(muted, player) { player.volume = if (muted) 0f else 1f }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        modifier = modifier,
        factory = {
            PlayerView(it).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                this.player = player
            }
        },
        update = { it.player = player },
    )
}

@Composable
private fun PrivacyDialog(context: Context, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.privacy_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.privacy_text), style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:waleedmmh789@gmail.com")
                    putExtra(Intent.EXTRA_SUBJECT, "waleed remix")
                }
                try { context.startActivity(intent) } catch (_: Exception) {}
            }) { Text(stringResource(R.string.support)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } },
    )
}

private fun formatDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}
