package com.waleed.remix

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val viewModel: RemixViewModel by viewModels()
    private lateinit var interstitial: InterstitialManager
    private lateinit var rewarded: RewardedManager
    private var adsStarted = false

    private fun startAds() {
        if (adsStarted) return
        adsStarted = true
        initAds(applicationContext)
        interstitial.load()
        rewarded.load()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        interstitial = InterstitialManager(applicationContext)
        rewarded = RewardedManager(applicationContext)
        // الإعلانات لا تبدأ إلا بعد موافقة المستخدم
        ConsentManager.gather(this) { startAds() }
        setContent {
            RemixTheme {
                RemixApp(
                    vm = viewModel,
                    onShowInterstitial = { interstitial.show(this) },
                    isRewardedReady = { rewarded.isReady() },
                    onShowRewarded = { onReward ->
                        rewarded.show(
                            activity = this,
                            onReward = onReward,
                            onUnavailable = {
                                Toast.makeText(this, getString(R.string.ad_not_ready), Toast.LENGTH_SHORT).show()
                            },
                        )
                    },
                )
            }
        }
    }
}
