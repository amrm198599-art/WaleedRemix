package com.waleed.remix

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * خدمة أمامية (Foreground) تُبقي التطبيق شغّالًا أثناء الضغط والدمج حتى لو قُفلت الشاشة،
 * وتعرض إشعار تقدّم.
 */
class ExportService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel(this)
        val text = intent?.getStringExtra(EXTRA_TEXT) ?: getString(R.string.notif_working)
        val notification = buildProgress(this, text, -1)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "waleedremix:work").apply {
                setReferenceCounted(false)
                acquire(15 * 60 * 1000L)
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "remix_progress"
        private const val NOTIF_ID = 1001
        private const val DONE_ID = 1002
        private const val EXTRA_TEXT = "text"

        /** هل هناك ضغط أو دمج شغال الآن (على مستوى التطبيق كله)؟ */
        @Volatile
        var busy = false

        fun start(ctx: Context, text: String) {
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, ExportService::class.java).putExtra(EXTRA_TEXT, text),
                )
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, ExportService::class.java))
            } catch (_: Exception) {
            }
        }

        /** [percent] من 0 إلى 100، أو -1 لإشعار غير محدد. */
        fun update(ctx: Context, text: String, percent: Int) {
            notifySafe(ctx, NOTIF_ID, buildProgress(ctx, text, percent))
        }

        /** إشعار نهائي (نجاح أو فشل) يبقى بعد إيقاف الخدمة. */
        fun done(ctx: Context, text: String) {
            createChannel(ctx)
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(ctx.getString(R.string.app_name))
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(openApp(ctx))
                .build()
            notifySafe(ctx, DONE_ID, n)
        }

        private fun buildProgress(ctx: Context, text: String, percent: Int): Notification {
            createChannel(ctx)
            val b = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(ctx.getString(R.string.app_name))
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openApp(ctx))
            if (percent < 0) b.setProgress(0, 0, true) else b.setProgress(100, percent.coerceIn(0, 100), false)
            return b.build()
        }

        private fun openApp(ctx: Context): PendingIntent {
            val intent = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            return PendingIntent.getActivity(
                ctx, 0, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }

        private fun createChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(CHANNEL) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(
                            CHANNEL,
                            ctx.getString(R.string.notif_channel),
                            NotificationManager.IMPORTANCE_LOW,
                        ),
                    )
                }
            }
        }

        private fun notifySafe(ctx: Context, id: Int, n: Notification) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED
                ) return
                NotificationManagerCompat.from(ctx).notify(id, n)
            } catch (_: Exception) {
            }
        }
    }
}
